package darkknights22.ultraseries.ultrafix;

import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Chest;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.util.Set;

public class Repair extends org.bukkit.plugin.java.JavaPlugin
{
    public Repair() {}

    public static final java.util.logging.Logger log = java.util.logging.Logger.getLogger("Minecraft");

    public void onEnable() {
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_AQUA + "=================================");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_PURPLE + "Status:" + ChatColor.BOLD + ChatColor.GREEN + "ENABLED");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_PURPLE + "Version:" + ChatColor.GOLD + "v1.2.0");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_PURPLE + "Author:" + ChatColor.GOLD + "DarkKnights22");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_AQUA + "=================================");
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(" ");
        if (!new java.io.File(getDataFolder(), "config.yml").exists()) {
            saveDefaultConfig();
        }
    }

    public void onDisable() {
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_AQUA + "=================================");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_PURPLE + "Status:" + ChatColor.BOLD + ChatColor.RED + "DISABLED");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_PURPLE + "Version:" + ChatColor.GOLD + "v1.2.0");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_PURPLE + "Author:" + ChatColor.GOLD + "DarkKnights22");
        Bukkit.getConsoleSender().sendMessage(ChatColor.DARK_RED + "[" + ChatColor.AQUA + "UltraFix" + ChatColor.DARK_RED + "]" + ChatColor.DARK_AQUA + "=================================");
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(" ");
        Bukkit.getConsoleSender().sendMessage(" ");
        saveConfig();
    }

    ArrayList<Player> cooldown = new ArrayList();



    public boolean onCommand(final CommandSender player, org.bukkit.command.Command cmd, String Label, String[] args)
    {
        if (Label.equalsIgnoreCase("fix")) {
            if (!(player instanceof Player)) {
                player.sendMessage(ChatColor.RED + "This command can only be run by a player.");
            }
            else if ((player instanceof Player)) {
                final Player p = (Player)player;
                if (player.hasPermission("ultrafix.fix")) {
                    if (cooldown.contains(p)) {
                        player.sendMessage(ChatColor.RED + "This command is on cooldown.");
                    }
                    else {
                        Player sender = (Player)player;
                        ItemStack berepaired = sender.getItemInHand();
                        if (itemCheck(berepaired)) {
                            berepaired.setDurability(

                                    (short)(berepaired.getType().getMaxDurability() - berepaired.getType().getMaxDurability()));
                            sender.sendMessage(ChatColor.GOLD + "You have repaired an item!");

                            if (getConfig().getBoolean("cd")) {
                                cooldown.add(p);
                                Bukkit.getServer()
                                        .getScheduler()
                                        .scheduleSyncDelayedTask(this, new Runnable()
                                        {

                                            public void run()
                                            {
                                                cooldown.remove(p);
                                            }

                                        }, getConfig().getLong("cooldown") * 20L);
                            }
                        } else {
                            sender.sendMessage(ChatColor.RED + "This item cannot be repaired.");
                        }
                    }
                }
                else {
                    player.sendMessage(ChatColor.RED + "You do not have permission.");
                }
            }
        }
        else if (Label.equalsIgnoreCase("fixall")) {
            if ((player instanceof Player)) {
                if (player.hasPermission("ultrafix.fixall")) {
                    if (cooldown.contains(player)) {
                        player.sendMessage(ChatColor.RED + "This command is on cooldown.");
                    }
                    else {
                        final Player p = (Player)player;
                        repair(p);

                        ItemStack[] arrayOfItemStack;
                        int localItemStack1 = (arrayOfItemStack = p.getInventory().getArmorContents()).length;
                        for (int ix = 0; ix < localItemStack1; ix++) {
                            ItemStack i = arrayOfItemStack[ix];
                            repair(i);
                        }
                        if (getConfig().getBoolean("cd")) {
                            cooldown.add(p);
                            Bukkit.getServer()
                                    .getScheduler()
                                    .scheduleSyncDelayedTask(this, new Runnable()
                                    {

                                        public void run()
                                        {
                                            cooldown.remove(p);
                                        }

                                    }, getConfig().getLong("cooldown") * 20L);
                        }
                    }
                } else {
                    player.sendMessage(ChatColor.RED + "You do not have permission.");
                }
            }
            else {
                player.sendMessage("You cannot do that.");
            }
        } else if (Label.equalsIgnoreCase("fixplayer")) {
            if ((player instanceof Player)) {
                final Player p = (Player)player;
                if (player.hasPermission("ultrafix.fixplayer")) {
                    if (cooldown.contains(p)) {
                        player.sendMessage(ChatColor.RED + "This command is on cooldown.");
                    }
                    else if (args.length == 0) {
                        p.sendMessage(ChatColor.RED + "Who's inventory would you like to fix?");
                    }
                    else if ((args.length == 1) &&
                            (p.getServer().getPlayer(args[0]) != null)) {
                        Player t = p.getServer().getPlayer(args[0]);
                        repair(t);
                        t.sendMessage(ChatColor.GOLD + "Your inventory has been fixed by " + p

                                .getName() + ".");
                        p.sendMessage(ChatColor.GOLD + "You have fixed " + t
                                .getName() + "'s inventory.");
                        if (getConfig().getBoolean("cd")) {
                            cooldown.add(p);
                            Bukkit.getServer()
                                    .getScheduler()
                                    .scheduleSyncDelayedTask(this, new Runnable()
                                    {

                                        public void run()
                                        {
                                            cooldown.remove(p);
                                        }

                                    }, getConfig().getLong("cooldown") * 20L);
                        }
                    }
                } else {
                    player.sendMessage(ChatColor.RED + "You don't have permission!");
                }
            }
        }
        else if (Label.equalsIgnoreCase("fixchest")) {
            Player p = (Player)player;
            if (cooldown.contains(p)) {
                p.sendMessage(ChatColor.RED + "This command is on cooldown.");
            } else if (p.hasPermission("ultrafix.fixchest")) {
                org.bukkit.block.Block b = p.getTargetBlock((Set<Material>) null, 5);
                if ((b.getType() == Material.CHEST) ||
                        (b.getType() == Material.TRAPPED_CHEST)) {
                    Chest c = (Chest)b.getState();
                    if (getConfig().getBoolean("cd")) {
                        cooldown.add(p);
                        Bukkit.getServer().getScheduler()
                                .scheduleSyncDelayedTask(this, new Runnable()
                                {
                                    public void run() {
                                        cooldown.remove(player);
                                    }
                                }, getConfig().getLong("cooldown") * 20L);
                    }
                    if (c.getInventory().getSize() == 54) {
                        for (int i = 0; i <= 54; i++) {
                            try {
                                ItemStack w = c.getInventory().getItem(i);
                                if (itemCheck(w))
                                {

                                    c.getInventory().getItem(i).setDurability(



                                            (short)(w.getType().getMaxDurability() - w.getType().getMaxDurability()));
                                }
                            }
                            catch (Exception localException1) {}
                        }
                    } else {
                        for (int i = 0; i <= 27; i++) {
                            try {
                                p.sendMessage(ChatColor.GOLD + "You have fixed all the items in this chest!");

                                ItemStack w = c.getInventory().getItem(i);
                                if (itemCheck(w))
                                {

                                    c.getInventory().getItem(i).setDurability(



                                            (short)(w.getType().getMaxDurability() - w.getType().getMaxDurability()));
                                }
                            }
                            catch (Exception localException2) {}
                        }
                    }
                } else {
                    p.sendMessage(ChatColor.RED + "This block isn't a chest.");
                }
            } else {
                player.sendMessage(ChatColor.RED + "You don't have permission!");
            }
        } else if (Label.equalsIgnoreCase("fixconfig")) {
            if (((player instanceof Player)) &&
                    (player.hasPermission("uktrafix.config")) && (args.length == 0))
            {
                Bukkit.broadcastMessage(ChatColor.GREEN + "Attempting to save and reload...");
                try
                {
                    saveConfig();
                    Bukkit.reload();
                    player.sendMessage(ChatColor.GREEN + "Complete!");
                } catch (Exception exc) {
                    player.sendMessage(ChatColor.RED + "Failure! Stack trace has been printed to console.");

                    log.warning("Stack trace from UltraFix:" + exc
                            .getStackTrace());
                }
            }
        }
        else if ((Label.equalsIgnoreCase("fixcd")) && ((player instanceof Player)))
        {
            if ((player.hasPermission("ultrafix.config")) && (args.length == 1))
            {
                Integer i = Integer.valueOf(args[0]);
                getConfig().set("cooldown", i);
                player.sendMessage(ChatColor.GREEN + "Cooldown has been set to " +
                        String.valueOf(i));
            }
        }

        return false;
    }

    private void repair(ItemStack i)
    {
        try {
            if (itemCheck(i)) {
                i.setDurability((short)0);
            }
        }
        catch (Exception localException) {}
    }

    public void repair(Player p) {
        for (int i = 0; i <= 36; i++) {
            try {
                ItemStack w = p.getInventory().getItem(i);
                if (itemCheck(w)) {
                    p.getInventory().getItem(i).setDurability((short)0);
                }
            }
            catch (Exception localException) {}
        }
    }

    private boolean itemCheck(ItemStack w) {
        if ((w.getType().getId() == 256) || (w.getType().getId() == 257) ||
                (w.getType().getId() == 258) || (w.getType().getId() == 259) ||
                (w.getType().getId() == 261) || (w.getType().getId() == 267) ||
                (w.getType().getId() == 268) || (w.getType().getId() == 269) ||
                (w.getType().getId() == 270) || (w.getType().getId() == 271) ||
                (w.getType().getId() == 272) || (w.getType().getId() == 273) ||
                (w.getType().getId() == 274) || (w.getType().getId() == 275) ||
                (w.getType().getId() == 276) || (w.getType().getId() == 277) ||
                (w.getType().getId() == 278) || (w.getType().getId() == 279) ||
                (w.getType().getId() == 283) || (w.getType().getId() == 284) ||
                (w.getType().getId() == 285) || (w.getType().getId() == 286) ||
                (w.getType().getId() == 290) || (w.getType().getId() == 291) ||
                (w.getType().getId() == 292) || (w.getType().getId() == 293) ||
                (w.getType().getId() == 294) || (w.getType().getId() == 298) ||
                (w.getType().getId() == 299) || (w.getType().getId() == 300) ||
                (w.getType().getId() == 301) || (w.getType().getId() == 302) ||
                (w.getType().getId() == 303) || (w.getType().getId() == 304) ||
                (w.getType().getId() == 305) || (w.getType().getId() == 306) ||
                (w.getType().getId() == 307) || (w.getType().getId() == 308) ||
                (w.getType().getId() == 309) || (w.getType().getId() == 310) ||
                (w.getType().getId() == 311) || (w.getType().getId() == 312) ||
                (w.getType().getId() == 313) || (w.getType().getId() == 314) ||
                (w.getType().getId() == 315) || (w.getType().getId() == 316) ||
                (w.getType().getId() == 317) || (w.getType().getId() == 346) ||
                (w.getType().getId() == 359)) {
            return true;
        }
        return false;
    }
}
